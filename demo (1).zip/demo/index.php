<?php
require_once("lib/database.php");
require_once("lib/function.php");
?>
<!DOCTYPE html>
<html lang="en">
<!--Head-part-->
   <?php include("segment/head.php");?>
<!--close-Head-part-->
<style> 

.loader {
  border: 16px solid #f3f3f3;
  border-radius: 50%;
  border-top: 16px solid blue;
  border-right: 16px solid green;
  border-bottom: 16px solid red;
  width: 120px;
  height: 120px;
  background:#f3f3f3;  
  -webkit-animation: spin 2s linear infinite;
  animation: spin 2s linear infinite;
  top: 0;  
  left: 0;  
  position: fixed;  
  opacity: 0.8;  
  z-index: 10000000;  
  margin: auto;  
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
</style>
<body>
  <div class="loader" id="AjaxLoader" style="display:none;">  
       <div class="strip-holder">  
       </div>  
   </div>
<!--Header-part-->
   <?php include("segment/header.php");?>   
<!--close-Header-part-->

<!--sidebar-menu-->
    <?php //include("segment/left_sidebar.php");?>
<!--close-sidebar-menu--> 
<style> .error{ color:red;display:none; }

</style>
  
<div id="content">
<div id="content-header">
  <div id="breadcrumb"> <a href="#" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a></div>
  <h1>Add Videos</h1>
</div>
<div class="container-fluid">
  <div id="show"></div>
   <div class="row-fluid">
    <div class="span12">
      <div class="widget-box">
        <div class="widget-title"> <span class="icon"> <i class="icon-align-justify"></i> </span>
          <h5>User Details</h5>
         </div>
         <div class="widget-content nopadding">
         <form class="form-horizontal" method="post" action="" id="validation" enctype="multipart/form-data"  >
      
        <!--Message-Part-Start-->
        <div class="alert alert-success" style="display:none;">
                  <button class="close" data-dismiss="alert">×</button>
                  <strong>Success ! </strong>Added Successfully. 
        </div>
      
        <div class="alert alert-error" style="display:none;">
                 <button class="close" data-dismiss="alert">×</button>
                  <strong>Error ! </strong> Something went wrong.please try again. 
        </div>

        <div class="alert alert-error2" style="display:none;">
                 <button class="close" data-dismiss="alert">×</button>
                  <strong>Error ! </strong> Some Fields are empty.please try again. 
        </div>
        <div class="alert alert-error3" style="display:none;">
                 <button class="close" data-dismiss="alert">×</button>
                  <strong>Error ! </strong> Mail Not Send. 
         </div>
        <div class="alert alert-error4" style="display:none;">
                 <button class="close" data-dismiss="alert">×</button>
                  <strong>Success ! </strong> Mail Successfully Send. 
        </div>
        <div class="alert alert-error0" style="display:none;">
                 <button class="close" data-dismiss="alert">×</button>
                  <strong>Error !</strong> You are already register with this Email Or Mobile !.
        </div>

       <div class="test"></div>
      <!--Message-Part-End-->
      
      <div class="control-group">
              <label class="control-label">Mobile :</label>
              <div class="controls">
                <input type="number" placeholder="Enter Mobile Number" class="span6"  name="mobile[]"/>
				<label id="error_name" class="error">Please Enter Test Name.</label>
            </div>
       </div>
       <div class="control-group">
              <label class="control-label">Email :</label>
              <div class="controls">
                <input type="text" placeholder="Enter Email" class="span6"  name="email[]">
				<label id="error_name" class="error">Please Enter Email.</label>
              </div>
        </div>      
        <div class="control-group">
        <div class="span4">    
              <label class="control-label">File Type : </label>
              <div class="controls">
        <input type="radio" name="file_type" value="video" class="file" checked> Video
               <!--<input type="radio" name="file_type" value="pdf" class="file"> Pdf-->
        </div>
        </div>
            
        <div class="span4"> 
         <label class="control-label">Category : </label>
         <div class="controls">
         <select name="category[]" id="cat_id" >
             <option value="">Select Category </option>
             <?php 
             $suc_child_cat = mysqli_query($conn,"select * from category where status='1'  order by id asc limit 3");
             while($detail = mysqli_fetch_array($suc_child_cat)){?>
             <option value="<?php echo $detail['id']; ?>"><?php echo $detail['category_name']; ?></option>
                   <?php  } ?>
               </select>
          </div>
        </div>  
    </div> 
        <div class="control-group">
            <div class="span4"> 
            <div class="control-group">
              <label class="control-label">Sub Category :</label>
              <div class="controls">
              <select id="sub_cat_id" class="span6" name="subcategory[]" style="width:170px;">
        <option value="">Select Sub Category</value>
        
        </select>
        <label id="error_sub_cat_id" class="error">Please Select Sub Category .</label>
              </div>
        </div> 
        </div>  
         <div class="span3"> 
         <div class="control-group">
              <label class="control-label">Sub Child Category :</label>
              <div class="controls">
                <select id="subchild_cat_id" class="span6" name="childcategory[]" style="width:170px;">
        <option value="">Select Sub Child Category</value>
        </select>
        <label id="error_sub_cat_id" class="error">Please Select Sub Child Category .</label>
              </div>
         </div> 
       </div> 
   
     <div class="span4"> 
            <label class="control-label">Chapter : </label>
          <div class="controls">
          <select name="chapter[]" id="cat_child_id" >
             <option >Select Chapter </option>
	  
               </select>
          </div>
        </div>  
 
        <div class="control-group">
          
         <div class="span12"  > 
            <label class="control-label">Videos : </label>
          <div class="controls" >
          <select name="videos[]" id="myFilter" data-spy="scroll"  class="multiple_select" style="width:100%;" multiple>
             <option  >Select Videos </option>

               </select>
               
          </div>
        </div>  
         
       
        </div>
        
        
        <style>
        select[multiple], select[size]{ height:42px;}
            
           :root
{
	--text: "Select values";
}
.multiple_select
{
	height: 18px;
	width: 90%;
	overflow: hidden;
	-webkit-appearance: menulist;
	position: relative;
}
.multiple_select::before
{
	content: var(--text);
	display: block;
  margin-left: 5px;
  margin-bottom: 2px;
}
.multiple_select_active
{
	overflow: visible !important;
}
.multiple_select option
{
	display: none;
    height: 18px;
	background-color: white;
}
.multiple_select_active option
{
	display: block;
}

.multiple_select option::before {
  content: "\2610";
}
.multiple_select option:checked::before {
  content: "\2611";
}





        </style>
        
        
        
          <div class="msg"></div>
        </div>
            <div class="form-actions" class="loader">
              <input type="button" value="Submit" class="btn btn-success add_file" >
            </div>
          </form>
        </div>
      </div>
      
      
    </div>
    
  </div>
 
</div></div>
<!--Footer-part-->
 <?php include("include/footer.php");?>
<!--end-Footer-part-->



<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

<script type="text/javascript">

$(".multiple_select").mousedown(function(e) {
    if (e.target.tagName == "OPTION") 
    {
      return; //don't close dropdown if i select option
    }
    $(this).toggleClass('multiple_select_active'); //close dropdown if click inside <select> box
});
$(".multiple_select").on('blur', function(e) {
    $(this).removeClass('multiple_select_active'); //close dropdown if click outside <select>
});
	
$('.multiple_select option').mousedown(function(e) { //no ctrl to select multiple
    e.preventDefault(); 
    $(this).prop('selected', $(this).prop('selected') ? false : true); //set selected options on click
    $(this).parent().change(); //trigger change event
});

	
	$("#myFilter").on('change', function() {
      var selected = $("#myFilter").val().toString(); //here I get all options and convert to string
      var document_style = document.documentElement.style;
      if(selected !== "")
        document_style.setProperty('--text', "'Selected: "+selected+"'");
      else
        document_style.setProperty('--text', "'Select values'");
	});





$(document).ready(function(){
    $('#cat_id').on("change",function () {
            var cat_Id = $(this).find('option:selected').val();
        //alert(cat_Id);
                $.ajax({
          url: "ajax/getSubCat.php",
          data: {cat_Ids:cat_Id},
          type: 'POST',
          success: function (result) {
                    $("#sub_cat_id").html(result);
            },
        });
    
    }); 
});

$(document).ready(function(){
    $('#sub_cat_id').on("change",function () {
            var subcat_Id = $(this).find('option:selected').val();
        //alert(subcat_Id);
                $.ajax({
          url: "ajax/getSubCat.php",
          data: {subcat_Ids:subcat_Id},
          type: 'POST',
          success: function (result) {
                    $("#subchild_cat_id").html(result);
            },
        });
    
    }); 
});

$(document).ready(function(){
    $('#subchild_cat_id').on("change",function () {
           // var subchild_Id = $(this).find('option:selected').val();
            var subcat_Id = $(this).find('option:selected').val();

        //alert(subcat_Id);
                $.ajax({
          url: "ajax/getSubCat.php",
          data: {subchild_Ids:subcat_Id },
          type: 'POST',
          success: function (result) {
                    $("#cat_child_id").html(result);
            },
        });
    
    }); 
});

$(document).ready(function(){
    $('#cat_child_id').on("change",function () {
           // var subchild_Id = $(this).find('option:selected').val();
            var subcat_Id = $(this).find('option:selected').val();

        //alert(subcat_Id);
                $.ajax({
          url: "ajax/getSubCat.php",
          data: {subchapter_Ids:subcat_Id },
          type: 'POST',
          success: function (result) {
                    $("#myFilter").html(result);
            },
        });
    
    }); 
});

</script>
<script src="js/jquery.min.js"></script> 
<script src="js/jquery.ui.custom.js"></script> 
<script src="js/bootstrap.min.js"></script>  
<script src="js/jquery.uniform.js"></script> 
<script src="js/select2.min.js"></script> 
<script src="js/matrix.js"></script> 
<script src="js/developer.js"></script> 
 <script src="js/developer-validation.js"></script> 
 <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script>
$(function() {
  $('#colorselector').change(function(){
    $('.colors').hide();
    $('#' + $(this).val()).show();
  });
});
</script>

<!--<div class="loader"></div>-->
</body>
</html>

<script>
$(document).ready(function(){
  
$("#add_more").click(function(){
  var rowNum = document.getElementById("add_more").rel;
  
  rowNum ++;
  
   var res='<div id="rowNum'+rowNum+'"><div class="control-group"><div class="span4"><label class="control-label">Title : </label><div class="controls"><input type="text" name="title[]" placeholder="Title" value=""></div></div><div class="span3"><label class="control-label">Sub Title : </label><div class="controls"><input type="text" name="sub_title[]" placeholder="Sub Title" value=""></div></div><div class="span3"> <div class="controls"><select name="type[]"><option value="">Select </option><option value="1">Free</option><option value="2">Price</option></select></div></div></div><div class="control-group"><div class="span4"><label class="control-label">File : </label><div class="controls"><input type="file" name="file[]" /></div></div><div class="span3"><label class="control-label">Description: </label><div class="controls"><input type="text" name="descp[]" placeholder="Description" value=""></div></div><div class="span4"><label class="control-label">duration: </label><div class="controls"><input type="number" name="dura[]" placeholder="duration" value=""></div></div><div class="span3"><a href="javascript:void(0);" onClick="removeRow('+rowNum+');" class="btn btn-danger btn-mini" style="float:right; margin-top:14px;"><strong><i class="icon icon-minus"></i> Remove</strong></a></div></div></div>';
  
  $(".anil").attr('rel',rowNum);
   $("#show_more").append(res);
   //$(".anil").hide();
   
});



 $(document)  
        .ajaxStart(function () {  
            $('#AjaxLoader').show();  
        })  
        .ajaxStop(function () {  
            $('#AjaxLoader').hide();  
        });  
        
        
$(document).delegate(".add_file","click",function(){
    
//     var file_type = $('.file:checked').val();
      var email = $("input[name='email[]']")
              .map(function(){return $(this).val();}).get();
              
      console.log(email);          
      var mobile = $("input[name='mobile[]']")
              .map(function(){return $(this).val();}).get();
                console.log(mobile); 
       //var videos = [];         
                
      var videos = $("select[name='videos[]']")
              .map(function(){return $(this).val();
                 
              }).get();
             
          
                console.log(videos); 
                

          //alert(file_type);return false;   
    var form_data = new FormData();
       form_data.append('email', email);
       form_data.append('mobile', mobile);
       //var arr = ['this', 'is', 'an', 'array'];
       for (var i = 0; i < videos.length; i++) {
           form_data.append('videos[]', videos[i]);
            }
     
    // form_data.append('subcategory', subcategory);
    // form_data.append('childcategory',childcategory);
    // form_data.append('type', type);
    // form_data.append('title', title); 
    // form_data.append('sub_title', sub_title); 
    // form_data.append('descp', descp);   
    // form_data.append('file', file);
    // form_data.append('files', files);
    // form_data.append('price', price); 
    // form_data.append('coupan', coupan);
    // form_data.append('dura',dura);
    // form_data.append('ship', ship);
    

    
    //alert(category);return false;   
    
    $.ajax({
      url: 'ajax/add_file.php', // point to server-side PHP script 
      dataType: 'text',  // what to expect back from the PHP script, if anything
      cache: false,
      contentType: false,
      processData: false,
      data: form_data,                        
      type: 'post',
      // this part is progress bar
                        // xhr: function () {
                        //     var xhr = new window.XMLHttpRequest();
                        //     xhr.upload.addEventListener("progress", function (evt) {
                        //         if (evt.lengthComputable) {
                        //             var percentComplete = evt.loaded / evt.total;
                        //             percentComplete = parseInt(percentComplete * 100);
                        //             $('.myprogress').text(percentComplete + '%');
                        //             $('.myprogress').css('width', percentComplete + '%');
                        //         }
                        //     }, false);
                        //     return xhr;
                        // },
        success: function (result) {
          //$('.test').html(result);
       //alert(result);return false;
       if(result==1){
            $("#validation")[0].reset();
            $(".error").hide();
            $('.alert-success').show();
            setTimeout(function() { $(".alert-success").hide(); }, 3000);
          }else if (result==2){
            $('.alert-error').show();
            setTimeout(function() { $(".alert-error").hide(); }, 3000);
          }else if (result==3){
            $('.alert-error2').show();
            setTimeout(function() { $(".alert-error2").hide(); }, 3000);
          }else if (result==4){ 
            $('.alert-error3').show();
            setTimeout(function() { $(".alert-error3").hide(); }, 3000);
          }else if (result==5){ 
            $('.alert-error4').show();
            setTimeout(function() { $(".alert-error4").hide(); }, 3000);
          }else if (result==0){ 
            $('.alert-error0').show();
            setTimeout(function() { $(".alert-error0").hide(); }, 3000);
          }else{
            $("#cat_validation")[0].reset();
            $(".error").hide();
            $('.alert-error1').show();
            setTimeout(function() { $(".alert-error1").hide(); }, 3000);
          }
        
    }
    });
                
});
});
function removeRow(rnum) {
$('#rowNum'+rnum).remove();
}
</script>

<script type = "text/javascript">
  // <!--
      // Form validation code will come here.
      function validateForm() {
     var x = document.getElementById("dura").value;
     if (x == "") {
    alert("Chapter Name must be filled out");
    return false;
  }
}
   //-->
</script>

<!--
  <div class="control-group"><div class="span4"><label class="control-label">Title : </label><div class="controls"><input type="text" name="title[]" placeholder="Title" value=""></div></div><div class="span3"><label class="control-label">Sub Title : </label><div class="controls"><input type="text" name="sub_title[]" placeholder="Sub Title" value=""></div></div><div class="span3"> <div class="controls"><select><option value="">Select </option><option value="1">Free</option><option value="2">Price</option></select></div></div></div>    
-->     