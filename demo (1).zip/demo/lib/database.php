<?php
//ob_start();
//session_start();
//if(substr_count($_SERVER['HTTP_ACCEPT_ENCODING'], 'gzip')) @ob_start("ob_gzhandler"); else @ob_start();
error_reporting(1); 
ini_set('arg_separator.output','&amp;');


	/* Live Server database Info*/
	define('DBSERVER',"localhost");
	define('DBNAME',"reale55y_dna");
	define('DBUSER',"reale55y_dna");
	define('DBPASS',"reale55y_dna");
// Database Connection Establishment String
//$conn = new mysqli(DB_HOST, DB_USER, DBPASS, DBNAME);
$conn = new mysqli(DBSERVER, DBUSER, DBPASS, DBNAME);

if ($conn->connect_error) { // Check connection
    die("Connection failed: " . $conn->connect_error);
}



	?>

                            
                            
                            
                            
