<?php
session_start();

/*f(isset($_SESSION['id']=='')){
	
	header("index.php");
	
}
*/

	?>

                            
                            
                            
                            