
<html>
<head>
	<title></title>
</head>
<body>
<p><strong>Exclusions and Limitations</strong></p>

<p>DNA APP Platform and Services are intended to be used within the jurisdiction of India only. Those who access or use DNA APP from other jurisdictions do so at their own volition and are responsible for compliance with the local law. Some jurisdictions do not allow the exclusion of certain warranties or the limitation or exclusion of liability for incidental or consequential damages. Accordingly, in certain jurisdictions, some of the above limitations of liability may not apply to You; all other provisions of these Terms remain in full force and effect.</p>

<p>&nbsp;</p>

<p>Indemnity</p>

<p>You agree to defend, indemnify and hold harmless DNA APP/CLASSES, its subsidiaries, affiliates, subcontractors, officers, directors, employees, consultants, representatives and agents, from and against any and all claims, damages, obligations, losses, liabilities, costs or expenses (including but not limited to attorneys&rsquo; fees and costs) arising from:</p>

<p>(i) your use of and access to the Website;</p>

<p>(j) third party claims from Parties who rely on your representations to them basis the information made available through the Services;</p>

<p>(k) your violation of any conditions in the Terms of Use and the Privacy Policy; or</p>

<p>(l) your violation of any third party right, including without limitation any copyright, property, or privacy right.</p>

<p>Additional Terms</p>

<p>We reserve the right at any time to modify, edit, delete, suspend or discontinue, temporarily or permanently the Service or Platform (or any portion thereof) with or without notice. You agree that we will not be liable to You or to any third party for any such modification, editing, deletion, suspension or discontinuance of website.</p>

<p>This Agreement and any rights and licenses granted here under, may not be transferred or assigned by You, but may be assigned by DNA APP without restriction.</p>

<p>These Terms of Use together with the Privacy Policy as well as subscription details such as pricing tables and any other legal notices published by DNA APP on the Platform, shall constitute the entire agreement between You and DNA APP concerning the Platform and governs your use of the Service and use of the Platform, superseding any prior agreements between You and DNA APP with respect to the subject matter covered in these Terms of Use.</p>

<p>The failure of DNA APP to exercise or enforce any right or provision of these Terms shall not constitute a waiver of such right or provision. If any provision of these Terms is found by a court of competent jurisdiction to be invalid, the parties nevertheless agree that the court should endeavour to give effect to the parties&rsquo; intentions as reflected in the provision, and the other provisions of this Agreement remain in full force and effect.</p>

<p>These Terms are governed by the laws of India. Any matters arising under these terms shall be subject to the exclusive jurisdiction of courts located in Bangalore.</p>

<p>Grievances</p>

<p>In case of any grievance arising from the use of Platform, please contact:</p>

<p>support@dnaclasses.com or xxxxxxxxxx.</p>
</body>
</html>
