<?php
include("../lib/database.php");
include("../lib/function.php");



$cat_name = $_POST['c_name'];
$category_id = $_POST['category'];
$subcategory_id = $_POST['subcategory'];

/*
if($_FILES['file']['name']!=""){
$tmp=$_FILES['file']['tmp_name'];
$file=time().basename($_FILES['file']['name']);
$serverpath="../img/category/".$file;
move_uploaded_file($tmp,$serverpath);
} */

/*
$total = "SELECT * FROM chapter WHERE ch_status='1'";
$totals= mysql_query($total);
if(mysql_num_rows($totals) > 2){
    	echo "3";
}else{ */   

$chkExit = "SELECT * FROM chapter WHERE ch_status='1' and ch_name='".$cat_name."'";
$chkExits= mysqli_query($conn,$chkExit);


if(empty($cat_name) || empty($category_id)){
 
     echo "3";
//}
//else if(mysqli_num_rows($chkExits) > 0){
	
//	echo "0";
	
}else{
	
	$insertCategory = mysqli_query($conn,"INSERT INTO `chapter` SET sub_child_id='".$category_id."', sub_cat_id='".$subcategory_id."', ch_name='$cat_name',ch_status='1',created=Now()");
	
	if($insertCategory){
		
		echo "1";
		
	}else{
		
		echo "2";
		
	}
	
/*}*/
}

?>