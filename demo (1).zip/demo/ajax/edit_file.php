<?php
include("../lib/database.php");
include("../lib/function.php");

//print_r($_POST);

$id=$_POST['id'];
$file_type = $_POST['file_type'];
$category =  $_POST['category'];
$sub_cat =  $_POST['subcategory'];
$sub_child =  $_POST['childcategory'];
$chapter =  $_POST['chapter'];
$type = $_POST['type'];
$title = $_POST['title'];
$sub = $_POST['sub_title'];
$descp = $_POST['descp'];
$dura = $_POST['dura'];
$price = $_POST['price'];
$coupan = $_POST['coupan'];
$shipping = $_POST['ship'];


/*
$typeArray = explode(",", $type);
$titleArray = explode(",", $title);
$subArray = explode(",", $sub);
$descpArray = explode(",", $descp);
*/
//for($i=0; $i < count($typeArray); $i++){

if($_FILES['file']['name']!=""){
$tmp=$_FILES['file']['tmp_name'];
$file=time().basename($_FILES['file']['name']);
$serverpath="../img/file/".$file;
move_uploaded_file($tmp,$serverpath);
}
if($_FILES['files']['name']!=""){
$tmp=$_FILES['files']['tmp_name'];
$files=time().basename($_FILES['files']['name']);
$serverpath="../img/faculty/".$files;
move_uploaded_file($tmp,$serverpath);
}
	

if(empty($file) || empty($files)){

$updateData = "UPDATE video_pdf SET file_type='$file_type',chapter_id='".$chapter."',cat_id='".$category."',sub_cat_id='".$sub_cat."',sub_child_cat='".$sub_child."',type='".$type."',title='".$title."',sub_title='".$sub."',`desc`='".$descp."',duration='".$dura."',`price`='".$price."', `coupan_id`='".$coupan."',`shipping_charge`='".$shipping."',status='1',created_on=Now() Where id= '".$id."'";

			if(mysqli_query($conn,$updateData)){
		
		        echo "1";
		
        	}else{
		
		       echo "2";
		
	       }

}else if(empty($file)){
           
 $updateData = "UPDATE video_pdf SET file_type='$file_type',chapter_id='".$chapter."',cat_id='".$category."',sub_cat_id='".$sub_cat."',sub_child_cat='".$sub_child."',type='".$type."',title='".$title."',sub_title='".$sub."',`desc`='".$descp."',duration='".$dura."',`dr_img`='$files',`price`='".$price."', `coupan_id`='".$coupan."',`shipping_charge`='".$shipping."',status='1',created_on=Now() Where id= '".$id."'";

			if(mysqli_query($conn,$updateData)){
		
		        echo "1";
		
        	}else{
		
		       echo "2";
		
	       }



}else{
		
	  $updateData = "UPDATE video_pdf SET file_type='$file_type',chapter_id='".$chapter."',cat_id='".$category."',sub_cat_id='".$sub_cat."',sub_child_cat='".$sub_child."',type='".$type."',file='$file',title='".$title."',sub_title='".$sub."',`desc`='".$descp."',duration='".$dura."',`dr_img`='$files',`price`='".$price."', `coupan_id`='".$coupan."',`shipping_charge`='".$shipping."',status='1',created_on=Now() Where id= '".$id."'";

			if(mysqli_query($conn,$updateData)){
		
		        echo "1";
		
        	}else{
		
		       echo "2";
		
	       }
			
}

?>