<?php
include("../lib/database.php");
include("../lib/function.php");

$c_id = $_POST['c_id'];
$status = $_POST['status'];
$coupan_name = $_POST['coupan_code'];
$coupan_value = $_POST['coupan_value'];
$coupan_date = $_POST['coupan_date'];



//print_r($_POST);die;

$chkExit = "SELECT * FROM coupans WHERE coupan_code='".$coupan_name."' AND id!='".$c_id."'";
$chkExits= mysqli_query($conn,$chkExit);

if(mysqli_num_rows($chkExits) > 0){
	
	echo "0";
	
}else{
	
	$updateCoupan = mysqli_query($conn,"UPDATE `coupans` SET `coupan_code` = '$coupan_name', `coupan_value`='$coupan_value',`expiry_date`='$coupan_date',`status`='$status' WHERE `c_id`='".$c_id."'");
	
	if($updateCoupan){
		
		echo "1";
		
	}else{
		
		echo "2";
		
	}
	
}


?>