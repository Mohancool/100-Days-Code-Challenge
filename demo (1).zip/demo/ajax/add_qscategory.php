<?php
include("../lib/database.php");
include("../lib/function.php");

$id = $_POST['cat_id'];
$sub_name =  $_POST['sub_name'];



/*print_r($_POST);die;
$typeArray = explode(",", $type);
$titleArray = explode(",", $title);
$subArray = explode(",", $sub);
$descpArray = explode(",", $descp);
*/
//for($i=0; $i < count($typeArray); $i++){

if($_FILES['cimage']['name']!=""){
$tmp=$_FILES['cimage']['tmp_name'];
$cimage=time().basename($_FILES['cimage']['name']);
$serverpath="../img/qcategory/".$cimage;
move_uploaded_file($tmp,$serverpath);
}
			


$chkExit = "SELECT * FROM qbank_subcat WHERE  cat_id='".$id."'  AND sub_cat_name='".$sub_name."'";
$chkExits= mysqli_query($conn,$chkExit);
if(mysql_num_rows($chkExits) > 0){
	
	echo "2";
	
}else{

		   $insertData = "INSERT INTO qbank_subcat SET cat_id='$id',sub_cat_name='$sub_name', image ='".$cimage."', status='1'";
		   
			if(mysqli_query($conn,$insertData)){
		
		        echo "1";
		
        	}else{
		
		       echo "2";
		
	       }
			
}

?>