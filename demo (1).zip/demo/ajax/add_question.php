<?php
include("../lib/database.php");
include("../lib/function.php");

//print_r($_POST);die;
$question = $_POST['question'];
$ans1 = $_POST['ans1'];
$ans2 = $_POST['ans2'];
$ans3 = $_POST['ans3'];
$ans4 = $_POST['ans4'];
$answer = $_POST['answer'];
$tid = $_POST['tid'];
$exp = $_POST['exp'];

	$addtest = mysqli_query($conn,"INSERT INTO test_question SET test_id='$tid',question='$question',ans1='$ans1',ans2='$ans2',ans3='$ans3',ans4='$ans4',currect_ans='$answer',explanation='$exp',created_on=Now()");
	
	if($addtest){
	
		echo "1";
		
	}else{
		
		echo "2";
		
	}
	



?>