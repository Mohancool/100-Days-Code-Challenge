<?php
include("../lib/database.php");
include("../lib/function.php");

$f_name = $_POST['f_name'];
$f_deg =  $_POST['f_deg'];
$f_desc = $_POST['f_desc'];
$f_quote = $_POST['f_quote'];
$f_cat = $_POST['f_cat'];

/*print_r($_POST);die;
$typeArray = explode(",", $type);
$titleArray = explode(",", $title);
$subArray = explode(",", $sub);
$descpArray = explode(",", $descp);
*/
//for($i=0; $i < count($typeArray); $i++){

if($_FILES['f_image']['name']!=""){
$tmp=$_FILES['f_image']['tmp_name'];
$f_image=time().basename($_FILES['f_image']['name']);
$serverpath="../img/faculty/".$f_image;
move_uploaded_file($tmp,$serverpath);
}
			
		   $insertData = "INSERT INTO faculty SET f_name='$f_name', f_image ='".$f_image."', f_deg='".$f_deg."', f_desc='".$f_desc."', f_quote='".$f_quote."',f_cat='".$f_cat."'";
		   
			if(mysqli_query($conn,$insertData)){
		
		        echo "1";
		
        	}else{
		
		       echo "2";
		
	       }
			
//}

?>