<?php
include("../lib/database.php");
include("../lib/function.php");



$cat_name = $_POST['cname'];


if($_FILES['cimage']['name']!=""){
$tmp=$_FILES['cimage']['tmp_name'];
$cimage=time().basename($_FILES['cimage']['name']);
$serverpath="../img/qcategory/".$cimage;
move_uploaded_file($tmp,$serverpath);
}
			
		   $insertData = "INSERT INTO qbank_cat SET cat_name='$cat_name', cat_image ='".$cimage."', status='1'  ";
		   
			if(mysqli_query($conn,$insertData)){
		
		        echo "1";
		
        	}else{
		
		       echo "2";
		
	       }
			
//}

?>