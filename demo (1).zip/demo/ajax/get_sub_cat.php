<?php
include("../lib/database.php");
include("../lib/function.php");
$id=$_POST["id"];			

 $suc_child_cat = mysqli_query($conn,"select * from sub_category where status=1 AND cat_id='".$id."'  order by id asc");
echo $suc_child_cat;
						
//}

?>