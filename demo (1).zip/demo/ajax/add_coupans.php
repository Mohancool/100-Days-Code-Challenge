<?php
include("../lib/database.php");
include("../lib/function.php");


$coupan_name = $_POST['coupan_code'];
$coupan_value = $_POST['coupan_value'];
$coupan_date = $_POST['coupan_date'];





$chkExit = "SELECT * FROM coupans WHERE status='1' and coupan_code='".$coupan_name."'";
$chkExits= mysqli_query($conn,$chkExit);

if(mysqli_num_rows($chkExits) > 0){
	
	echo "0";
	
}else{
	
	$insertCoupan = mysqli_query($conn,"INSERT INTO `coupans` SET `coupan_code` = '$coupan_name', `coupan_value`='$coupan_value',expiry_date='$coupan_date',status='1'");
	
	if($insertCoupan){
		
		echo "1";
		
	}else{
		
		echo "2";
		
	}
	
/*}*/
}

?>