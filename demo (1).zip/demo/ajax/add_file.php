<?php
include("../lib/database.php");
include("../lib/function.php");

//print_r($_POST['videos']);

$email_id = $_POST['email'];
$mobile =  $_POST['mobile'];
$video_id = $_POST['videos'];
$mverify_code = mt_rand(111111,999999);

//$video = explode(",", $video_id);


function send_mail($conn,$to,$user_id,$mobile,$video_id)
{ 
	require_once('PHPMailer-master/PHPMailer-master/PHPMailerAutoload.php');
         $mail = new PHPMailer;
    
    $mail->isSMTP();                                        // Set mailer to use SMTP
    $mail->Host = 'mail.pgmedeg.com';    // Specify main and backup SMTP servers    mail.classic.com'
    $mail->SMTPAuth = true;                                 // Enable SMTP authentication
    $mail->Username = 'info@pgmedeg.com';     // SMTP username
    $mail->Password = 'MedEG!@#$';                          // SMTP password
    $mail->SMTPSecure = 'tls';                              // Enable TLS encryption, `ssl` also accepted
    $mail->Port = '25'; 
    $mail->setFrom('info@pgmedeg.com', 'DNA App');
    $mail->Subject = 'Welcome to DNA App';
    
    //$to="info@pgmedeg.com";
    //$to ="modassir.shams@gmail.com";    
    $mail->addAddress($to, 'DNA App');    
    $mail->AddBCC('dnahelpgroup@gmail.com', "DNA App");                  
    //$mail->addAddress('21amansg@gmail.com', 'AMAN');     // Add a recipient
    $mail->addReplyTo('info@pgmedeg.com', 'DNA App');
    $mail->headers= $headers;
    //Send HTML or Plain Text email
    $mail->isHTML(true); 
    $mail->Subject = 'Videos Demo Instructions';
    $start = round(microtime(true) * 1000);
    $end =  round(microtime(true) * 1000) + 7200000;

    foreach($video_id as $value){
      $x .= $value.",";
       }
     $result = rtrim($x,',');
   $link = 'http://vrok.in/'.$user_id.'/'.$to.'/'.$mobile.'/'.$start.'/'.$end.'/';  
  $content2= '<html><body>

                 <b>Hello</b><br><br>You have requested for demo of videos. <a href='.$link.' target='._blank.'>Click here</a> to get your demo videos. If you are unable to click the link then copy the below link and paste in your browser to get your videos demo .<br><i>". $link."</i>";
	       <table bgcolor="#ffffff"  bordercolor="#0EAAA6" width="750" border="2">
                <tr><td>
                    <table bgcolor="#ffffff" width="750" border="0">
                    <tr>
                      <td colspan="2" align="center" style="padding-left:10px;padding-top:9px;width:635px;font-size:11px;font-family:verdana;min-height:33px;padding-bottom:9px;">
                    <img src="http://13.234.161.7/img/dnalogo.jpeg" alt="DNA App" width="150" height="100" class="img-responsive"/></td>
                    </tr>
                    <tr bgcolor="#0EAAA6">
                      <td colspan="2" align="center" style="font-size:12px;font-family:Trajan Pro;color:#ffffff;">    </td>
                    </tr>
                    <tr><td colspan="2" align="center" style="text-align:center;"></td></tr>
                    <tr><td colspan="2" align="center">
                        <table width="100" border="0">
                          <tr><td valign="top">&nbsp;&nbsp;</td>
                        <td valign="top">
                            <table border="0" width="640" style="color:#666666;text-align:justify; line-height:1.9; font-size:14px;">
                            <tr><td>
                            <br>
                             Mobile: '.$mobile.',<br>
                             Email:'.$to.',<br>
                             Link: '.$link.',<br>
                            <br>Thanks
                            <br>DNA Team
                            <br>
                            </td></tr>
                              </table>
                        </td><td valign="top">&nbsp;&nbsp;</td></tr>
                        </table>
                    </td></tr>
                    </table>
                </td></tr>
                </table>

    
                </body></html>';
    $mail->Body = $content2;
    $mail->send();
				
	if(!$mail->send()) {
		return 'fail';
	} else {
		return 'success';
	}
}

$chkExits = mysqli_query($conn,"Select * from customer where email_id = '".$email_id."' OR mobile_no = '".$mobile."' ");
		
if(empty($email_id) || empty($mobile) || empty($video_id) ){

//if(empty($video_id)){

echo "3";

} else if(mysqli_num_rows($chkExits) > 0){
	
	echo "0";
	
}else{	
	    
//	$Insert="INSERT INTO customer SET name='$name',username='$username', email_id='$email_id', `mobile_no`='$mobile', password='$password',state='$state',image='$image_file',mverify_code='$mverify_code',
				//	college='$college',status ='1',created_on =now()";
	$Insert= mysqli_query($conn,"INSERT INTO `customer` (`id`, `name`, `username`, `email_id`, `mobile_no`, `image`, `password`, `fb_id`, `state`, `college`, `status`, `mverify_code`, `created_on`) VALUES (NULL, '', '', '$email_id', '$mobile', '', '', '', '', '', '1', '$mverify_code', now())");
		 
		 if($Insert){
		   $insert_id=mysqli_insert_id($conn);
	       foreach ($video_id as $value) {
		   $select =mysqli_query($conn,"INSERT INTO user_payment_status SET user_id ='$insert_id',video_id = '".$value."', payment_status= '1', created_on=now()");
		
	       }
	     	if($select){
		      
		      $response = send_mail($conn,$email_id,$insert_id,$mobile,$video_id);
							if($response == 'success')
							{
							   echo "1";
							}else{

                                                           echo "4";
							}
			//	echo "1";
	     	 	}else{
		
                       echo "2";
		
	                     }
	       
		 }
}

?>