<?php
include("../lib/database.php");
include("../lib/function.php");
if(isset($_POST['cat_Id']))
{
 $cat_id = $_POST['cat_Id'];


	$sub_cat = mysqli_query($conn,"SELECT * FROM sub_category WHERE cat_id='".$cat_id."'");
	$sub_cat_no = mysqli_num_rows($sub_cat);
	if($sub_cat_no > 0){
		echo "<option value=''>Select Sub Category</option>";
		while($sub_cat_details = mysqli_fetch_array($sub_cat)){
			echo '<option value="'.$sub_cat_details['id'].'">'.$sub_cat_details['sub_cat_name'].'</option>';
		}
		
	}else{
		echo "<option value=''>First Add Sub Category</option>";
	}
}
	
if(isset($_POST['cat_Ids']))
{
	$cat_ids = $_POST['cat_Ids'];
	$sub_cat = mysqli_query($conn,"SELECT * FROM sub_category WHERE cat_id='".$cat_ids."' and status='1'");
	$sub_cat_no = mysqli_num_rows($sub_cat);
	if($sub_cat_no > 0){
		echo "<option value=''>Select Sub Category</option>";
		while($sub_cat_details = mysqli_fetch_array($sub_cat)){
			echo '<option value="'.$sub_cat_details['id'].'">'.$sub_cat_details['sub_cat_name'].'</option>';
		}
		
	}else{
		echo "<option value=''>First Add Sub Category</option>";
	}
	
	
}	
if(isset($_POST['subcat_Ids']))
{
	$subcat_ids = $_POST['subcat_Ids'];
	$sub_cat = mysqli_query($conn,"SELECT * FROM sub_child_category WHERE sub_cat_id='".$subcat_ids."' and status='1'");
	$sub_cat_no = mysqli_num_rows($sub_cat);
	if($sub_cat_no > 0){
		echo "<option value=''>Select Sub Child Category</option>";
		while($sub_cat_details = mysqli_fetch_array($sub_cat)){
			echo '<option value="'.$sub_cat_details['id'].'">'.$sub_cat_details['sub_child_name'].'</option>';
		}
		
	}else{
		echo "<option value=''>First Add Sub Child Category</option>";
	}
	
	
}

if(isset($_POST['subchild_Ids']))
{
	$subcat_ids = $_POST['subchild_Ids'];
	$sub_cat = mysqli_query($conn,"SELECT * FROM chapter WHERE sub_child_id='".$subcat_ids."' and ch_status='1'");
	$sub_cat_no = mysqli_num_rows($sub_cat);
	if($sub_cat_no > 0){
		echo "<option >Select Chapter</option>";
		while($sub_cat_details = mysqli_fetch_array($sub_cat)){
			echo '<option value="'.$sub_cat_details['ch_id'].'">'.$sub_cat_details['ch_name'].'</option>';
		}
		
	}else{
		echo "<option value=''>First Add Sub Child Category</option>";
	}
	
	
}

if(isset($_POST['subchapter_Ids']))
{
	$subcat_ids = $_POST['subchapter_Ids'];
	$sub_cat = mysqli_query($conn,"SELECT * FROM video_pdf WHERE chapter_id='".$subcat_ids."'");
	$sub_cat_no = mysqli_num_rows($sub_cat);
	if($sub_cat_no > 0){
		echo "<option value=''>Select Videos</option>";
		while($sub_cat_details = mysqli_fetch_array($sub_cat)){
			echo '<option value="'.$sub_cat_details['id'].'">'.$sub_cat_details['title'].'</option>';
		}
		
	}else{
		echo "<option value=''>First Select Chapter</option>";
	}
	
	
}


?>