<?php
include("../lib/database.php");
include("../lib/function.php");

$subcat_id = $_POST['subcat_id'];
$cat_id = $_POST['cat_id'];
$id = $_POST['c_id'];
$name = $_POST['c_name'];
//$category = $_POST['category'];
$status = $_POST['c_status'];


/*
$chkExit = "SELECT * FROM chapter WHERE ch_name='".$name."' AND ch_id!='".$id."'";
$chkExits= mysqli_query($conn,$chkExit);

if(mysqli_num_rows($chkExits) > 0){
	
	echo "0";
	
}else{
*/	
	$updateChapter = mysqli_query($conn,"UPDATE `chapter` SET `sub_cat_id` = '$subcat_id',`sub_child_id` = '$cat_id',`ch_name` = '$name', `ch_status`='$status' WHERE `ch_id`='".$id."'");
	
	if($updateChapter){
		
		echo "1";
		
	}else{
		
		echo "2";
		
	}
	
//}



?>