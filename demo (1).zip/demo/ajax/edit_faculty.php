<?php
include("../lib/database.php");
include("../lib/function.php");

$f_id = $_POST['f_id'];
$f_name = $_POST['f_name'];
$status = $_POST['status'];
$f_deg = $_POST['f_deg'];
$f_desc = $_POST['f_desc'];
$f_quote = $_POST['f_quote'];



if($_FILES['f_image']['name']!=""){
$tmp=$_FILES['f_image']['tmp_name'];
$file=time().basename($_FILES['f_image']['name']);
$serverpath="../img/faculty/".$file;
move_uploaded_file($tmp,$serverpath);
}else{
$file = $_POST['file1'];	
}

//print_r($_POST);die;

$chkExit = "SELECT * FROM faculty WHERE f_id='".$f_id."'";
$chkExits= mysqli_query($conn,$chkExit);

if(mysqli_num_rows($chkExits) > 0){
	
	echo "0";
	
}else{
	
	$updateCategory = mysqli_query($conn,"UPDATE `faculty` SET f_name='$f_name',f_image='$file',f_deg='$f_deg',f_desc=$f_desc,status='$status',created_on=Now() WHERE id='".$cat_id."'");
	
	if($updateCategory){
		
		echo "1";
		
	}else{
		
		echo "2";
		
	}
	
}


?>