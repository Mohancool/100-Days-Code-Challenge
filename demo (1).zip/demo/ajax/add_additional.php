<?php
include("../lib/database.php");
include("../lib/function.php");


//$id = $_POST['id'];
$discount = $_POST['type'];






	
	$insertCoupan = mysqli_query($conn,"INSERT INTO `additional_discount` SET `discount_percent` ='".$discount."' ");
	
	if($insertCoupan){
		
		echo "1";
		
	}else{
		
		echo "2";
		
	}
	
/*}*/


?>