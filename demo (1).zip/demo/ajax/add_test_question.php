<?php
include("../lib/database.php");
include("../lib/function.php");

//print_r($_POST);die;
$test_id = $_POST['test_id'];
$files = $_POST['files'];
$name = $_POST['name'];
$optiona = $_POST['optiona'];
$optionb = $_POST['optionb'];
$optionc = $_POST['optionc'];
$optiond = $_POST['optiond'];
$canswer = $_POST['canswer'];
$editor1 = $_POST['editor1'];



if($_FILES['files']['name']!="") {

$uploadedFile = $_FILES['files']['tmp_name']; 
$sourceProperties = getimagesize($uploadedFile);
$FileName = $_FILES['files']['name'];
$ext = substr($FileName, strrpos($FileName, "."));
$newFiles = time().basename($FileName, $ext);
$file = time().basename($FileName, $ext)."_thump".$ext;
$dirPath = "../questionimg/";
$ext = pathinfo($_FILES['files']['name'], PATHINFO_EXTENSION);
$imageType = $sourceProperties[2];


switch ($imageType){
          
    case IMAGETYPE_PNG:
        $imageSrc = imagecreatefrompng($uploadedFile); 
        $tmp = imageResize($imageSrc,$sourceProperties[0],$sourceProperties[1]);
        imagepng($tmp,$dirPath. $newFiles. "_thump.". $ext);
        break;           

    case IMAGETYPE_JPEG:
        $imageSrc = imagecreatefromjpeg($uploadedFile); 
        $tmp = imageResize($imageSrc,$sourceProperties[0],$sourceProperties[1]);
        imagejpeg($tmp,$dirPath. $newFiles. "_thump.". $ext);
        break;
    
    case IMAGETYPE_GIF:
        $imageSrc = imagecreatefromgif($uploadedFile); 
        $tmp = imageResize($imageSrc,$sourceProperties[0],$sourceProperties[1]);
        imagegif($tmp,$dirPath. $newFiles. "_thump.". $ext);
        break;

    default:
        echo "Invalid Image type.";
        exit;
        break;
}



}else{
$file='';	
}

	
	$addtest = mysqli_query($conn,"INSERT INTO test_question SET test_id='$test_id',question='$name',question_image='$file',
	ans1='$optiona',ans2='$optionb',ans3='$optionc',ans4='$optiond',currect_ans='$canswer',explanation='$editor1',created_on=Now()");
	
	if($addtest){
	
		echo "1";
		
	}else{
		
		echo "2";
		
	}
	

function imageResize($imageSrc,$imageWidth,$imageHeight) {

    $newImageWidth =190;
    $newImageHeight =190;

    $newImageLayer=imagecreatetruecolor($newImageWidth,$newImageHeight);
    imagecopyresampled($newImageLayer,$imageSrc,0,0,0,0,$newImageWidth,$newImageHeight,$imageWidth,$imageHeight);

    return $newImageLayer;
}

?>