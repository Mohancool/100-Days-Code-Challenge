<?php
include("../lib/database.php");
include("../lib/function.php");


$video_id = $_POST['s_id'];
$name = $_POST['s_name'];
$time = $_POST['s_time'];





//$chkExit = "SELECT * FROM tbl_video_topic_duration WHERE video_id='".$video_id."' And topic_name='".$name."'";
//$chkExits= mysqli_query($conn,$chkExit);

//if(mysqli_num_rows($chkExits) > 0){
	
//	echo "0";
	
//}else{
	
	$insertCoupan = mysqli_query($conn,"INSERT INTO `tbl_video_topic_duration` SET `video_id` = '".$video_id."', `topic_name`='$name',`source_time`='$time',`auto_date`= now()");
	
	if($insertCoupan){
		
		echo "1";
		
	}else{
		
		echo "2";
		
	}
	
/*}*/
//}

?>