<div class="row-fluid">
  <div id="footer" class="span12"> 2018 &copy; DAN Admin. Powered by <a href="http://akwebtech.com/" target="_blank">Ak Web tech</a> </div>
</div>



