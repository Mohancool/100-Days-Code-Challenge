<?php
$url =  $_SERVER['PHP_SELF']; 
$urlArray = explode("/",$url);
$page = $urlArray[3];
?>

<div id="sidebar">
<a href="#" class="visible-phone"><i class="icon icon-reorder"></i> Menu</a>
  <ul>
  
	<li class="<?php if($page=='dashboard.php'){ echo "active";}?>"><a href="dashboard.php"><i class="icon icon-dashboard"></i> <span>Dashboard</span></a></li>
	
    <li class="submenu <?php if($page=='manage_admin.php' || $page=='view_admin.php'){ echo "active open";}?>"> <a href="#"><i class="icon icon-th-list"></i> <span>Admin </span></a>
      <ul>
        <li class="<?php if($page=='manage_admin.php' || $page=='view_admin.php'){ echo "active";}?>"><a href="manage_admin.php">Manage Admin</a></li>
      </ul>
    </li>

	<li class="submenu <?php if($page=='add_category.php' || $page=='manage_category.php' || $page=='edit_category.php'){ echo "active open";}?>"> <a href="#"><i class="icon icon-home"></i> <span>Category </span></a>
      <ul>
	    <li class="<?php if($page=='add_category.php'){ echo "active";}?>"><a href="add_category.php">Add Category</a></li>
        <li class="<?php if($page=='manage_category.php' || $page=='edit_category.php'){ echo "active";}?>"><a href="manage_category.php">Manage Category</a></li>
      </ul>
    </li>
	
	<li class="submenu <?php if($page=='add_subcategory.php' || $page=='manage_subcategory.php' || $page=='edit_subcategory.php'){ echo "active open";}?>"> <a href="#"><i class="icon icon-home"></i> <span>Sub Category </span></a>
      <ul>
	    <li class="<?php if($page=='add_subcategory.php'){ echo "active";}?>"><a href="add_subcategory.php">Add Sub Category</a></li>
        <li class="<?php if($page=='manage_subcategory.php' || $page=='edit_subcategory.php'){ echo "active";}?>"><a href="manage_subcategory.php">Manage Sub Category</a></li>
      </ul>
    </li>
	
	<li class="submenu <?php if($page=='add_childcategory.php' || $page=='manage_childcategory.php' || $page=='edit_childcategory.php'){ echo "active open";}?>"> <a href="#"><i class="icon icon-home"></i> <span>Sub Child Category</span></a>
      <ul>
	    <li class="<?php if($page=='add_childcategory.php'){ echo "active";}?>"><a href="add_childcategory.php">Add Sub Child Category</a></li>
        <li class="<?php if($page=='manage_childcategory.php' || $page=='edit_childcategory.php'){ echo "active";}?>"><a href="manage_childcategory.php">Manage Sub Child Category</a></li>
      </ul>
    </li>

    <li class="submenu <?php if($page=='add_videochapter.php' || $page=='manage_videochapter.php' || $page=='edit_videochapter.php'){ echo "active open";}?>"> <a href="#"><i class="icon icon-home"></i> <span>Chapters</span></a>
      <ul>
             <li class="<?php if($page=='add_videochapter.php'){ echo "active";}?>"><a href="add_videochapter.php">Add Video Chapter</a></li>
         <li class="<?php if($page=='manage_videochapter.php' || $page=='edit_videochapter.php'){ echo "active";}?>"><a href="manage_videochapter.php">Manage Video Chapter</a></li>
      </ul>
    </li>

    <li class="submenu <?php if($page=='add_file.php' || $page=='manage_file.php' || $page=='edit_file.php'){ echo "active open";}?>"> <a href="#"><i class="icon icon-home"></i> <span>All Video/Pdf</span></a>
      <ul>
        <li class="<?php if($page=='add_file.php'){ echo "active";}?>"><a href="add_file.php">Add Video/Pdf</a></li>
        <li class="<?php if($page=='manage_file.php' || $page=='edit_file.php'){ echo "active";}?>"><a href="manage_file.php">Manage Video/Pdf</a></li>
      </ul>
    </li>
    
    
    <li class="submenu <?php if($page=='add_test.php' || $page=='manage_test.php' || $page=='edit_test.php' || $page=='add_question.php' || $page=='manage_test_question.php'){ echo "active open";}?>"> <a href="#"><i class="icon icon-home"></i> <span>Test</span></a>
      <ul>
	    <li class="<?php if($page=='add_test.php'){ echo "active";}?>"><a href="add_test.php">Add Test</a></li>
        <li class="<?php if($page=='manage_test.php' || $page=='edit_test.php' || $page=='add_question.php' || $page=='manage_test_question.php'){ echo "active";}?>"><a href="manage_test.php">Manag Test</a></li>
        <li class="<?php if($page=='add_test.php'){ echo "active";}?>"><a href="excel_add.php">Add Test Question</a></li>
        <li class="<?php if($page=='add_test.php'){ echo "active";}?>"><a href="add_test_question.php">Add Single Test Question </a></li>
      </ul>
    </li>
    
    <li class="submenu <?php if($page=='add_test.php' || $page=='manage_test.php' || $page=='edit_test.php' || $page=='add_question.php' || $page=='manage_test_question.php'){ echo "active open";}?>"> <a href="#"><i class="icon icon-home"></i> <span>Faculty</span></a>
      <ul>
      <li class="<?php if($page=='add_faculty.php'){ echo "active";}?>"><a href="add_faculty.php">Add Faculty</a></li>
        <li class="<?php if($page=='manage_test.php' || $page=='edit_test.php' || $page=='add_question.php' || $page=='manage_test_question.php'){ echo "active";}?>"><a href="manage_faculty.php">Manage Faculty</a></li>
      </ul>
    </li>
    <li class="submenu <?php if($page=='add_test.php' || $page=='manage_test.php' || $page=='edit_test.php' || $page=='add_question.php' || $page=='manage_test_question.php'){ echo "active open";}?>"> <a href="#"><i class="icon icon-home"></i> <span>Faculty Head</span></a>
      <ul>
      <li class="<?php if($page=='add_faculty.php'){ echo "active";}?>"><a href="add_faculty_head.php">Add Faculty Head</a></li>
        <li class="<?php if($page=='manage_test.php' || $page=='edit_test.php' || $page=='add_question.php' || $page=='manage_test_question.php'){ echo "active";}?>"><a href="manage_faculty_head.php">Manage Faculty Head</a></li>
      </ul>
    </li>
     <li class="submenu <?php if($page=='add_test.php' || $page=='manage_test.php' || $page=='edit_test.php' || $page=='add_question.php' || $page=='manage_test_question.php'){ echo "active open";}?>"> <a href="#"><i class="icon icon-home"></i> <span>QBank Category</span></a>
      <ul>
      <li class="<?php if($page=='add_qcategory.php'){ echo "active";}?>"><a href="add_qcategory.php">Add Category</a></li>
        <li class="<?php if($page=='manage_test.php' || $page=='edit_test.php' || $page=='add_question.php' || $page=='manage_test_question.php'){ echo "active";}?>"><a href="manage_qbank_category.php">Manage Category</a></li>
      </ul>
    </li>


      <li class="submenu <?php if($page=='add_test.php' || $page=='manage_test.php' || $page=='edit_test.php' || $page=='add_question.php' || $page=='manage_test_question.php'){ echo "active open";}?>"> <a href="#"><i class="icon icon-home"></i> <span>QBank Sub Category</span></a>
      <ul>
      <li class="<?php if($page=='add_qscategory.php'){ echo "active";}?>"><a href="add_qscategory.php">Add Sub Category</a></li>
        <li class="<?php if($page=='manage_test.php' || $page=='edit_test.php' || $page=='add_question.php' || $page=='manage_test_question.php'){ echo "active";}?>"><a href="manage_qbank_subcategory.php">Manage Sub Category</a></li>
      </ul>
    </li>

    <li class="submenu <?php if($page=='add_test.php' || $page=='manage_test.php' || $page=='edit_test.php' || $page=='add_question.php' || $page=='manage_test_question.php'){ echo "active open";}?>"> <a href="#"><i class="icon icon-home"></i> <span>Users</span></a>
      <ul>
        <li class="<?php if($page=='manage_test.php' || $page=='edit_test.php' || $page=='add_question.php' || $page=='manage_test_question.php'){ echo "active";}?>"><a href="manage_users.php">Manage Users</a></li>
      </ul>
    </li>
    
     <li class="submenu <?php if($page=='add_test.php' || $page=='manage_test.php' || $page=='edit_test.php' || $page=='add_question.php' || $page=='manage_test_question.php'){ echo "active open";}?>"> <a href="#"><i class="icon icon-home"></i> <span>Additional Discount</span></a>
      <ul>
        <li class="<?php if($page=='manage_test.php' || $page=='edit_test.php' || $page=='add_question.php' || $page=='add_additional.php'){ echo "active";}?>"><a href="add_additional.php">Add Discount</a></li>
      </ul>
    </li>

    <li class="submenu <?php if($page=='add_test.php' || $page=='manage_test.php' || $page=='edit_test.php' || $page=='add_question.php' || $page=='manage_test_question.php'){ echo "active open";}?>"> <a href="#"><i class="icon icon-home"></i> <span>Coupans</span></a>
      <ul>
      <li class="<?php if($page=='add_qscategory.php'){ echo "active";}?>"><a href="add_coupans.php">Add Coupans</a></li>
        <li class="<?php if($page=='manage_test.php' || $page=='edit_test.php' || $page=='add_question.php' || $page=='manage_test_question.php'){ echo "active";}?>"><a href="manage_coupans.php">Manage Coupans</a></li>
      </ul>
    </li>


	<li class="submenu <?php if($page=='change_password.php'){ echo "active open";}?>"> <a href="#"><i class="icon icon-wrench"></i> <span>Setting </span></a>
      <ul>
        <li class="<?php if($page=='change_password.php'){ echo "active";}?>"><a href="change_password.php">Change Password</a></li>
      </ul>
    </li>
  </ul>
</div>

<script>


</script>