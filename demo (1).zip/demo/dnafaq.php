
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>DNA::APP</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style type="text/css">
    .bs-example{
    	margin: 20px;
    }
    .rotate{
		-webkit-transform: rotate(90deg);  /* Chrome, Safari, Opera */
			-moz-transform: rotate(90deg);  /* Firefox */
			-ms-transform: rotate(90deg);  /* IE 9 */
				transform: rotate(90deg);  /* Standard syntax */    
    }
    panel-default>.panel-heading {
    background-color: #fff;
}
</style>
<script>
    $(document).ready(function(){
        // Add minus icon for collapse element which is open by default
        $(".collapse.in").each(function(){
        	$(this).siblings(".panel-heading").find(".glyphicon").addClass("rotate");
        });
        
        // Toggle plus minus icon on show hide of collapse element
        $(".collapse").on('show.bs.collapse', function(){
        	$(this).parent().find(".glyphicon").addClass("rotate");
        }).on('hide.bs.collapse', function(){
        	$(this).parent().find(".glyphicon").removeClass("rotate");
        });
    });
</script>
</head>
<body>
<div class="bs-example">
    <h3>General Questions</h3>
    <div class="panel-group" id="accordion">
        <div class="panel panel-default">
            <div class="panel-heading" style="background-color:#fff;">
                <h4 class="panel-title">
                    <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne"><span class="glyphicon glyphicon-menu-right"></span>1.Why DNA As Your Learning Partner ?</a>
                </h4>
            </div>
            <div id="collapseOne" class="panel-collapse collapse">
                <div class="panel-body">
                <img src="img/dnavideo.JPG" class="img-responsive" />
                </div>
            </div>
        </div>
        <div class="panel panel-default">
            <div class="panel-heading" style="background-color:#fff;">
                <h4 class="panel-title">
                    <a data-toggle="collapse" data-parent="#accordion" href="#collapseTwo"><span class="glyphicon glyphicon-menu-right"></span>2.Can I Use DNA App In More Than One Devices ?</a>
                </h4>
            </div>
            <div id="collapseTwo" class="panel-collapse collapse">
                <div class="panel-body">
                    <p style="font-family:times new roman;font-size:18px;">Simultaneously usages in two devices is not allowed.sharing account is not allowed , it will result in account blocking permanently without any prior Notice/warning.</p>
                </div>
            </div>
        </div>
        <div class="panel panel-default">
            <div class="panel-heading" style="background-color:#fff;">
                <h4 class="panel-title">
                    <a data-toggle="collapse" data-parent="#accordion" href="#collapseThree"><span class="glyphicon glyphicon-menu-right"></span>3.what do you mean by Live Online Lectures ?</a>
                </h4>
            </div>
            <div id="collapseThree" class="panel-collapse collapse">
                <div class="panel-body">
                    <p style="font-family:times new roman;font-size:18px;"> Live Online sessions are Video Lecture directly relay from the Face to Face coaching Classes. These session are live only & that can’t be Recorded
                    or replayed. These session only be attended when it is live.</p>
                </div>
            </div>
        </div>
        <div class="panel panel-default">
            <div class="panel-heading" style="background-color:#fff;">
                <h4 class="panel-title">
                    <a data-toggle="collapse" data-parent="#accordion" href="#collapseFour"><span class="glyphicon glyphicon-menu-right"></span>
                    4.Is DNA App is Sufficient To secure good rank in Exam like NEET-PG / NET-SS / AIIMS ?</a>
                </h4>
            </div>
            <div id="collapseFour" class="panel-collapse collapse">
                <div class="panel-body">
                    <p style="font-family:times new roman;font-size:18px;"> Exam rank is depends upon how you are using this DNA App contents ,your Hard work & your luck all together. But yes , DNA App Contents is sufficient to secure good rank .</p>
                </div>
            </div>
        </div>
        <div class="panel panel-default">
            <div class="panel-heading" style="background-color:#fff;">
                <h4 class="panel-title">
                    <a data-toggle="collapse" data-parent="#accordion" href="#collapseFive"><span class="glyphicon glyphicon-menu-right"></span>
                    5. Should I join DNA if I have already joined Face to Face classes / other Online App / satellite classes ?</a>
                </h4>
            </div>
            <div id="collapseFive" class="panel-collapse collapse">
                <div class="panel-body">
                    <p style="font-family:times new roman;font-size:18px;"> If you have already joined Face to Face coaching classes / Satellite Classes / Other Online App then No Need to Join All packages , you should follow you classes 
            provided by your institution and if you find difficulties in any Subjects then join that Subject Video Lecture from DNA.</p>
            <p style="font-family:times new roman;font-size:18px;">you can join Q Bank Series & Test Series by DNA to get extra Edge.</p>
                </div>
            </div>
        </div>
        <div class="panel panel-default">
            <div class="panel-heading" style="background-color:#fff;">
                <h4 class="panel-title">
                    <a data-toggle="collapse" data-parent="#accordion" href="#collapseSix"><span class="glyphicon glyphicon-menu-right"></span>
                    6. From which year of MBBS we should join DNA for preparation ?</a>
                </h4>
            </div>
            <div id="collapseSix" class="panel-collapse collapse">
                <div class="panel-body">
                    <p style="font-family:times new roman;font-size:18px;">If you are MBBS Students then join DNA as early as possible with packages which includes your  Subjects like 1st year MBBS should join Anatomy, physiology
            & Biochemistry means 1st Prof package. 2nd year Students should choose 2nd prof package . Pre final year Students should take 3rd Prof package & Final
            year Students should take Final Prof package.</p>
           
                </div>
            </div>
        </div>
        <div class="panel panel-default">
            <div class="panel-heading" style="background-color:#fff;">
                <h4 class="panel-title">
                    <a data-toggle="collapse" data-parent="#accordion" href="#collapseSeven"><span class="glyphicon glyphicon-menu-right"></span>
                    7. Is DNA have separate package for NEET- SS ?</a>
                </h4>
            </div>
            <div id="collapseSeven" class="panel-collapse collapse">
                <div class="panel-body">
                    <p style="font-family:times new roman;font-size:18px;">Yes, for NEE-SS there is separate video Lectures & Test Series as per super speciality branch</p>
           
                </div>
            </div>
        </div>
        <div class="panel panel-default">
            <div class="panel-heading" style="background-color:#fff;">
                <h4 class="panel-title">
                    <a data-toggle="collapse" data-parent="#accordion" href="#collapseEight"><span class="glyphicon glyphicon-menu-right"></span>
                   8. Is DNA provides separate coaching for FMG ( MCI Screening )</a>
                </h4>
            </div>
            <div id="collapseEight" class="panel-collapse collapse">
                <div class="panel-body">
                    <p style="font-family:times new roman;font-size:18px;">Yes, for MCI Screening Video Lectures , Q Bank & Test Series are available in separate package..</p>
           
                </div>
            </div>
        </div>
        <div class="panel panel-default">
            <div class="panel-heading" style="background-color:#fff;">
                <h4 class="panel-title">
                    <a data-toggle="collapse" data-parent="#accordion" href="#collapseNine"><span class="glyphicon glyphicon-menu-right"></span>
                    9.can I  upgrade plan /package  ?</a>
                </h4>
            </div>
            <div id="collapseNine" class="panel-collapse collapse">
                <div class="panel-body">
                    <p style="font-family:times new roman;font-size:18px;">No upgrade Possible after buying the package.</p>
           
                </div>
            </div>
        </div>
        <div class="panel panel-default">
            <div class="panel-heading" style="background-color:#fff;">
                <h4 class="panel-title">
                    <a data-toggle="collapse" data-parent="#accordion" href="#collapseTen"><span class="glyphicon glyphicon-menu-right"></span>
                    10.How a password can be changed ?</a>
                </h4>
            </div>
            <div id="collapseTen" class="panel-collapse collapse">
                <div class="panel-body">
                    <p style="font-family:times new roman;font-size:18px;">For reset your password click here</p>
           
                </div>
            </div>
        </div>
    </div>

</div>
</body>
</html>                                		                                		                            